Drop your photos in this folder using these exact names (JPG, ideally under 500 KB each):

  arun.png          your portrait (now your LinkedIn photo)
  about.jpg         optional: a different photo for the "engineer / finance" section (then change aboutPhoto in index.html)
  golf-1.jpg  golf-2.jpg  golf-3.jpg
  pickleball-1.jpg  pickleball-2.jpg
  cooking-1.jpg     cooking-2.jpg
  roadtrip-1.jpg    roadtrip-2.jpg
  hike-1.jpg        hike-2.jpg

Want more or fewer gallery photos? Edit the "hobbies" list in the content block at the top of index.html.
Any missing photo shows a labeled empty frame instead of breaking.
